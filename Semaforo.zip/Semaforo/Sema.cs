﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Semaforo
{
    internal class Sema
    {
        int rua = 0;

        private byte estado;
        

        public Sema()
        {

            this.rua = 0;
            // com rua1 = vd e rua2 = vm - situação inicial
        }
        public Sema(byte estado)
        {
            this.estado = estado;
        }
        public void setVerde(int rua)
        {
            if rua = 1;
            {
                pictureBox1 = Sema.Properties.Resources.verd;
            
            }else rua = 2;
            pictureBox1 = Sema.Properties.Resources.verd;
        }

        public void setAmarelo(int rua)
        {
            if rua = 1;
            {
                pictureBox1 = Sema.Properties.Resources.am;

            }else rua = 2;
            pictureBox1 = Sema.Properties.Resources.am;
        }

        public void setVermelho(int rua)
        {
            if rua = 1;
            {
                pictureBox1 = Sema.Properties.Resources.ver;

            }else rua = 2;
            pictureBox1 = Sema.Properties.Resources.ver;
        }

        public byte getEstado()
        {
            return this.estado;
        }

        public int getEstado(int rua)
        {
            // 1. Vd - 2. Am - 3. Vm
            byte aux = 0;
            return aux;
        }
    }
}


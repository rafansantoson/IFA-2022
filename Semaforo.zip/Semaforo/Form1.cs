﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Semaforo
{
    public partial class Form1 : Form
    {
        private Sema rua;
        public Form1()
        {
            InitializeComponent();
            pictureBox1 = 0;
            pictureBox2 = 0;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1 = Sema.Properties.Resources.verd;
            btn1.Enabled = true;
            btn2.Enabled = false;
            btn3.Enabled = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox1 = Sema.Properties.Resources.am;
            btn1.Enabled = false;
            btn2.Enabled = true;
            btn3.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pictureBox1 = Sema.Properties.Resources.ver;
            btn1.Enabled = false;
            btn2.Enabled = false;
            btn3.Enabled = true;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1 = Sema.Properties.Resources.verd;
            btn1.Enabled = false;
            btn3.Enabled = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
